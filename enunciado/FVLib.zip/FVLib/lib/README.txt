The libFVLib.a repertory
