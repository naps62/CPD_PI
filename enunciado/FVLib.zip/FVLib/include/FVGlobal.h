#ifndef _FVGLOBAL 
#define _FVGLOBAL

static unsigned int nb_thread=1;  // number of threads using by openMP 
extern unsigned int nb_thread;
#endif // define _FVGLOBAL
