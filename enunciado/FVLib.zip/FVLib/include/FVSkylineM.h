// ------ FVFVSkylineMatrice.h ------
// S. CLAIN 2011/07
#ifndef _FVSkylineM
#define _FVSkylineM

#include <FVVect>
template<class T_> class FVSkylineM : public valarray<T_>
{
private:
  
public: 
}
#endif // define _FVSkylineM 

 
 